package com.nhatnam.server.utils;

import com.nhatnam.server.entity.ExpenseItem;
import com.nhatnam.server.entity.ExpenseVoucher;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Dựng file Excel BÁO CÁO PHIẾU CHI theo khoảng thời gian.
 *
 * <h3>"Merge giả" cho phiếu nhiều khoản chi</h3>
 * Mỗi khoản chi là MỘT dòng. Các cột đầu phiếu (thời gian tạo, trạng thái, NCC, tổng tiền...)
 * <b>vẫn có dữ liệu ở mọi dòng</b> (để lọc/pivot đúng), nhưng ở các dòng sau dòng đầu thì chữ
 * được tô CÙNG MÀU NỀN nên nhìn như đã gộp ô. Riêng cột "Tổng tiền" chỉ để giá trị ở dòng đầu,
 * các dòng sau = 0 (ẩn) để {@code SUM} không bị cộng trùng.
 */
public final class ExpenseReportExcel {

    private ExpenseReportExcel() {}

    private static final ZoneId TZ = ZoneId.of("Asia/Ho_Chi_Minh");
    private static final DateTimeFormatter DT = DateTimeFormatter.ofPattern("HH:mm dd/MM/yyyy");
    private static final DateTimeFormatter D  = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private static final byte[] WHITE  = {(byte) 0xFF, (byte) 0xFF, (byte) 0xFF};
    private static final byte[] ALT_BG = {(byte) 0xFA, (byte) 0xF7, (byte) 0xF2};
    private static final byte[] NAVY   = {(byte) 0x1A, (byte) 0x1A, (byte) 0x2E};
    private static final byte[] GOLD   = {(byte) 0xC9, (byte) 0xA8, (byte) 0x4C};

    public static byte[] buildReport(List<ExpenseVoucher> vouchers, long from, long to,
                                     String exportedBy, boolean showPaymentCol,
                                     String methodLabel) throws Exception {
        try (XSSFWorkbook wb = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            XSSFSheet sheet = wb.createSheet("Phiếu chi");
            DataFormat df = wb.createDataFormat();

            // ── Chỉ số cột động ──────────────────────────────────────────────
            int c = 0;
            final int CREATED = c++, STATUS = c++, APPROVED = c++, CREATOR = c++, APPROVER = c++,
                    VENDOR = c++, PERIOD = c++, REASON = c++;
            final int PAYCOL = showPaymentCol ? c++ : -1;
            final int TOTAL = c++;
            final int CAT = c++;
            final int AMOUNT = c++;
            final int lastCol = AMOUNT;

            // ── Styles ───────────────────────────────────────────────────────
            CellStyle title = wb.createCellStyle();
            XSSFFont titleFont = wb.createFont(); titleFont.setBold(true); titleFont.setFontHeightInPoints((short) 14);
            title.setFont(titleFont); title.setAlignment(HorizontalAlignment.CENTER); title.setVerticalAlignment(VerticalAlignment.CENTER);

            CellStyle meta = wb.createCellStyle();
            XSSFFont metaFont = wb.createFont(); metaFont.setItalic(true); metaFont.setFontHeightInPoints((short) 10);
            meta.setFont(metaFont); meta.setAlignment(HorizontalAlignment.CENTER);

            CellStyle header = wb.createCellStyle();
            XSSFFont headerFont = wb.createFont(); headerFont.setBold(true); headerFont.setColor(new XSSFColor(WHITE, null));
            header.setFont(headerFont);
            header.setFillForegroundColor(new XSSFColor(NAVY, null)); header.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            header.setAlignment(HorizontalAlignment.CENTER); header.setVerticalAlignment(VerticalAlignment.CENTER);
            header.setWrapText(true); header.setBorderBottom(BorderStyle.THIN);

            // Text hiển thị (thường / xen kẽ) + biến thể wrap cho Nội dung
            CellStyle dataN = text(wb, null, false);
            CellStyle dataA = text(wb, ALT_BG, false);
            CellStyle reasonN = text(wb, null, true);
            CellStyle reasonA = text(wb, ALT_BG, true);
            // Text ẩn (chữ trùng màu nền) — dùng cho dòng khoản chi thứ 2 trở đi
            CellStyle hidN = hiddenText(wb, null);
            CellStyle hidA = hiddenText(wb, ALT_BG);
            // Số tiền hiển thị
            CellStyle amtN = amount(wb, df, null, false);
            CellStyle amtA = amount(wb, df, ALT_BG, false);
            // Số tiền ẩn (giá trị 0 ở dòng sau) — chữ trùng nền
            CellStyle amtHidN = amount(wb, df, null, true);
            CellStyle amtHidA = amount(wb, df, ALT_BG, true);

            int rowIdx = 0;

            // ── Row 0: Tiêu đề ───────────────────────────────────────────────
            Row titleRow = sheet.createRow(rowIdx++);
            titleRow.setHeightInPoints(28);
            Cell tc = titleRow.createCell(0); tc.setCellValue("BÁO CÁO PHIẾU CHI"); tc.setCellStyle(title);
            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, lastCol));

            // ── Row 1: Meta ──────────────────────────────────────────────────
            String fromStr = Instant.ofEpochMilli(from).atZone(TZ).format(D);
            String toStr   = Instant.ofEpochMilli(to).atZone(TZ).format(D);
            String exportedAt = java.time.LocalDateTime.now(TZ).format(DT);
            Row metaRow = sheet.createRow(rowIdx++);
            metaRow.setHeightInPoints(18);
            Cell mc = metaRow.createCell(0);
            mc.setCellValue("Từ " + fromStr + " đến " + toStr
                    + "     |     PTTT: " + methodLabel
                    + "     |     Xuất lúc: " + exportedAt
                    + "     |     Người xuất: " + (exportedBy != null ? exportedBy : ""));
            mc.setCellStyle(meta);
            sheet.addMergedRegion(new CellRangeAddress(1, 1, 0, lastCol));

            // ── Row 2: trống ─────────────────────────────────────────────────
            sheet.createRow(rowIdx++);

            // ── Row 3: Header ────────────────────────────────────────────────
            Row hRow = sheet.createRow(rowIdx++);
            hRow.setHeightInPoints(28);
            String[] labels = new String[lastCol + 1];
            labels[CREATED] = "Thời gian tạo";
            labels[STATUS] = "Trạng thái";
            labels[APPROVED] = "Thời gian duyệt";
            labels[CREATOR] = "Người tạo";
            labels[APPROVER] = "Người duyệt";
            labels[VENDOR] = "Nhà cung cấp";
            labels[PERIOD] = "Thời gian / Kỳ";
            labels[REASON] = "Nội dung";
            if (PAYCOL >= 0) labels[PAYCOL] = "Phương thức thanh toán";
            labels[TOTAL] = "Tổng tiền";
            labels[CAT] = "Danh mục khoản chi";
            labels[AMOUNT] = "Số tiền";
            for (int i = 0; i <= lastCol; i++) {
                Cell hc = hRow.createCell(i);
                hc.setCellValue(labels[i]);
                hc.setCellStyle(header);
            }

            final int dataStart = rowIdx; // 0-based dòng dữ liệu đầu tiên

            // ── Data ─────────────────────────────────────────────────────────
            for (int vi = 0; vi < vouchers.size(); vi++) {
                ExpenseVoucher v = vouchers.get(vi);
                boolean alt = (vi % 2 == 1);

                List<ExpenseItem> items = v.getItems() == null ? new ArrayList<>() : new ArrayList<>(v.getItems());
                if (items.isEmpty()) items.add(null); // luôn ít nhất 1 dòng

                BigDecimal total = items.stream().filter(Objects::nonNull)
                        .map(ExpenseItem::getAmount).filter(Objects::nonNull)
                        .reduce(BigDecimal.ZERO, BigDecimal::add);

                String createdStr  = v.getCreatedAt() != null ? Instant.ofEpochMilli(v.getCreatedAt()).atZone(TZ).format(DT) : "";
                String statusStr   = statusLabel(v.getStatus());
                String approvedStr = v.getApprovedAt() != null ? Instant.ofEpochMilli(v.getApprovedAt()).atZone(TZ).format(DT) : "";
                String creatorStr  = nz(v.getCreatedByName());
                String approverStr = nz(v.getApprovedByName());
                String vendorStr   = nz(v.getVendorName());
                String periodStr   = timeOrPeriod(v);
                String reasonStr   = nz(v.getReason());
                String payStr      = v.getPaymentType() == ExpenseVoucher.PaymentType.BANK_TRANSFER ? "Chuyển khoản" : "Tiền mặt";

                for (int j = 0; j < items.size(); j++) {
                    boolean first = (j == 0);
                    ExpenseItem it = items.get(j);
                    Row row = sheet.createRow(rowIdx++);
                    row.setHeightInPoints(18);

                    // Cột đầu phiếu (merge giả): luôn ghi dữ liệu; dòng sau dùng style ẩn
                    putText(row, CREATED, createdStr, first, alt, dataN, dataA, hidN, hidA);
                    putText(row, STATUS, statusStr, first, alt, dataN, dataA, hidN, hidA);
                    putText(row, APPROVED, approvedStr, first, alt, dataN, dataA, hidN, hidA);
                    putText(row, CREATOR, creatorStr, first, alt, dataN, dataA, hidN, hidA);
                    putText(row, APPROVER, approverStr, first, alt, dataN, dataA, hidN, hidA);
                    putText(row, VENDOR, vendorStr, first, alt, dataN, dataA, hidN, hidA);
                    putText(row, PERIOD, periodStr, first, alt, dataN, dataA, hidN, hidA);
                    putText(row, REASON, reasonStr, first, alt, reasonN, reasonA, hidN, hidA);
                    if (PAYCOL >= 0) putText(row, PAYCOL, payStr, first, alt, dataN, dataA, hidN, hidA);

                    // Tổng tiền: dòng đầu = tổng (hiện), dòng sau = 0 (ẩn) → SUM không sai
                    Cell totalCell = row.createCell(TOTAL);
                    totalCell.setCellValue(first ? total.doubleValue() : 0d);
                    totalCell.setCellStyle(first ? (alt ? amtA : amtN) : (alt ? amtHidA : amtHidN));

                    // Danh mục + số tiền của từng khoản (luôn hiện)
                    Cell catCell = row.createCell(CAT);
                    catCell.setCellValue(it != null ? nz(it.getItemName()) : "");
                    catCell.setCellStyle(alt ? dataA : dataN);

                    Cell amtCell = row.createCell(AMOUNT);
                    amtCell.setCellValue(it != null && it.getAmount() != null ? it.getAmount().doubleValue() : 0d);
                    amtCell.setCellStyle(alt ? amtA : amtN);
                }
            }

            // ── Độ rộng cột ──────────────────────────────────────────────────
            sheet.setColumnWidth(CREATED, 20 * 256);
            sheet.setColumnWidth(STATUS, 14 * 256);
            sheet.setColumnWidth(APPROVED, 20 * 256);
            sheet.setColumnWidth(CREATOR, 20 * 256);
            sheet.setColumnWidth(APPROVER, 20 * 256);
            sheet.setColumnWidth(VENDOR, 26 * 256);
            sheet.setColumnWidth(PERIOD, 16 * 256);
            sheet.setColumnWidth(REASON, 32 * 256);
            if (PAYCOL >= 0) sheet.setColumnWidth(PAYCOL, 20 * 256);
            sheet.setColumnWidth(TOTAL, 16 * 256);
            sheet.setColumnWidth(CAT, 28 * 256);
            sheet.setColumnWidth(AMOUNT, 16 * 256);
            sheet.createFreezePane(0, dataStart);

            // ── Dòng TỔNG CỘNG (SUM cột "Số tiền" của từng khoản) ────────────
            int totalRowIdx = rowIdx;
            Row totalRow = sheet.createRow(totalRowIdx);
            totalRow.setHeightInPoints(20);

            CellStyle totalLabel = wb.createCellStyle();
            XSSFFont tf = wb.createFont(); tf.setBold(true);
            totalLabel.setFont(tf); totalLabel.setAlignment(HorizontalAlignment.RIGHT);
            totalLabel.setFillForegroundColor(new XSSFColor(GOLD, null)); totalLabel.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            CellStyle totalSum = wb.createCellStyle();
            totalSum.setFont(tf); totalSum.setAlignment(HorizontalAlignment.RIGHT);
            totalSum.setDataFormat(df.getFormat("#,##0"));
            totalSum.setFillForegroundColor(new XSSFColor(GOLD, null)); totalSum.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            Cell lbl = totalRow.createCell(0);
            lbl.setCellValue("TỔNG CỘNG (" + vouchers.size() + " phiếu)");
            lbl.setCellStyle(totalLabel);
            if (AMOUNT - 1 >= 0) sheet.addMergedRegion(new CellRangeAddress(totalRowIdx, totalRowIdx, 0, AMOUNT - 1));

            Cell sumCell = totalRow.createCell(AMOUNT);
            String amtColLetter = CellReference.convertNumToColString(AMOUNT);
            if (rowIdx > dataStart) {
                sumCell.setCellFormula("SUM(" + amtColLetter + (dataStart + 1) + ":" + amtColLetter + rowIdx + ")");
            } else {
                sumCell.setCellValue(0);
            }
            sumCell.setCellStyle(totalSum);

            wb.write(out);
            return out.toByteArray();
        }
    }

    // ── style factories ────────────────────────────────────────────────────────
    private static CellStyle text(XSSFWorkbook wb, byte[] bg, boolean wrap) {
        CellStyle s = wb.createCellStyle();
        s.setVerticalAlignment(VerticalAlignment.TOP);
        s.setWrapText(wrap);
        s.setBorderBottom(BorderStyle.THIN);
        if (bg != null) { s.setFillForegroundColor(new XSSFColor(bg, null)); s.setFillPattern(FillPatternType.SOLID_FOREGROUND); }
        return s;
    }

    /** Chữ trùng màu nền → text bị "ẩn" nhưng dữ liệu vẫn còn trong ô. */
    private static CellStyle hiddenText(XSSFWorkbook wb, byte[] bg) {
        CellStyle s = wb.createCellStyle();
        s.setVerticalAlignment(VerticalAlignment.TOP);
        s.setBorderBottom(BorderStyle.THIN);
        XSSFFont f = wb.createFont();
        f.setColor(new XSSFColor(bg != null ? bg : WHITE, null)); // chữ = màu nền
        s.setFont(f);
        if (bg != null) { s.setFillForegroundColor(new XSSFColor(bg, null)); s.setFillPattern(FillPatternType.SOLID_FOREGROUND); }
        return s;
    }

    private static CellStyle amount(XSSFWorkbook wb, DataFormat df, byte[] bg, boolean hidden) {
        CellStyle s = wb.createCellStyle();
        s.setVerticalAlignment(VerticalAlignment.TOP);
        s.setAlignment(HorizontalAlignment.RIGHT);
        s.setDataFormat(df.getFormat("#,##0"));
        s.setBorderBottom(BorderStyle.THIN);
        if (hidden) {
            XSSFFont f = wb.createFont();
            f.setColor(new XSSFColor(bg != null ? bg : WHITE, null));
            s.setFont(f);
        }
        if (bg != null) { s.setFillForegroundColor(new XSSFColor(bg, null)); s.setFillPattern(FillPatternType.SOLID_FOREGROUND); }
        return s;
    }

    private static void putText(Row row, int col, String value, boolean first, boolean alt,
                                CellStyle nStyle, CellStyle aStyle, CellStyle hidN, CellStyle hidA) {
        Cell cell = row.createCell(col);
        cell.setCellValue(value);
        if (first) cell.setCellStyle(alt ? aStyle : nStyle);
        else       cell.setCellStyle(alt ? hidA : hidN);
    }

    private static String statusLabel(ExpenseVoucher.VoucherStatus s) {
        if (s == null) return "";
        return switch (s) {
            case PENDING -> "Chờ duyệt";
            case APPROVED -> "Đã duyệt";
            case REJECTED -> "Từ chối";
        };
    }

    /** Cột "Thời gian / Kỳ": theo ngày → dd/MM/yyyy; theo kỳ → "Kỳ yyyy-MM". */
    private static String timeOrPeriod(ExpenseVoucher v) {
        if (v.getExpenseDate() != null) {
            return Instant.ofEpochMilli(v.getExpenseDate()).atZone(TZ).format(D);
        }
        if (v.getExpensePeriod() != null && !v.getExpensePeriod().isBlank()) {
            return "Kỳ " + v.getExpensePeriod();
        }
        return "";
    }

    private static String nz(String s) { return s == null ? "" : s; }
}
