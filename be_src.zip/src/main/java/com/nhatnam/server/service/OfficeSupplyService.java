package com.nhatnam.server.service;

import com.nhatnam.server.common.BusinessException;
import com.nhatnam.server.common.ResourceNotFoundException;
import com.nhatnam.server.dto.supply.OfficeSupplyDtos.*;
import com.nhatnam.server.entity.*;
import com.nhatnam.server.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class OfficeSupplyService {

    private final OfficeSupplyRequestRepository requestRepo;
    private final OfficeSupplyOrderRepository   orderRepo;
    private final SupplyWarehouseRepository     warehouseRepo;
    private final SupplyItemRepository          itemRepo;
    private final UserRepository                userRepo;
    // supplyItemService KHÔNG inject qua constructor để tránh vòng phụ thuộc
    // (SupplyItemService không phụ thuộc OfficeSupplyService nhưng để mở nếu
    // tương lai có mở rộng); truyền vào chính method admin* nhằm mục đích rõ.

    // ─────────────────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────────────────

    private User currentUser() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepo.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("Người dùng không tồn tại"));
    }

    private SupplyWarehouse warehouse(Long warehouseId) {
        return warehouseRepo.findById(warehouseId)
                .orElseThrow(() -> new ResourceNotFoundException("Văn phòng không tồn tại"));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Danh mục vật dụng (với thống kê)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Danh sách vật dụng kèm thống kê (số lần mua, ngày mua gần nhất)
     * theo văn phòng. Dùng cho trang đăng ký của nhân viên và trang kho của owner.
     */
    @Transactional(readOnly = true)
    public List<OfficeItemDto> listItems(Long warehouseId) {
        List<SupplyItem> items = itemRepo.findByDeletedAtIsNullOrderByNameAsc();

        // Thống kê theo kho
        Map<Long, Object[]> statsMap = new HashMap<>();
        if (warehouseId != null) {
            orderRepo.statsByItemAndWarehouse(warehouseId)
                    .forEach(row -> statsMap.put((Long) row[0], row));
        }

        return items.stream().map(it -> {
            Object[] stats = statsMap.get(it.getId());
            return OfficeItemDto.builder()
                    .id(it.getId())
                    .name(it.getName())
                    .specification(it.getSpecification())
                    .unit(it.getUnit())
                    .orderCount(stats != null ? (Long) stats[1] : 0L)
                    .lastOrderedAt(stats != null ? (Long) stats[2] : null)
                    .totalQuantity(stats != null ? (BigDecimal) stats[3] : BigDecimal.ZERO)
                    .build();
        }).collect(Collectors.toList());
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Phiếu đăng ký của nhân viên
    // ─────────────────────────────────────────────────────────────────────────

    /** Lấy phiếu đăng ký hiện tại của user (tất cả văn phòng). */
    @Transactional(readOnly = true)
    public List<MyRequestDto> myRequests() {
        User user = currentUser();
        return requestRepo.findAllByUserIdWithItems(user.getId()).stream()
                .map(this::toMyRequestDto)
                .collect(Collectors.toList());
    }

    /** Lưu / cập nhật phiếu đăng ký của user cho 1 văn phòng. */
    @Transactional
    public MyRequestDto saveRequest(SaveRequestBody body) {
        User user = currentUser();
        SupplyWarehouse wh = warehouse(body.getWarehouseId());

        OfficeSupplyRequest req = requestRepo
                .findByUserIdAndWarehouseId(user.getId(), wh.getId())
                .orElseGet(() -> OfficeSupplyRequest.builder()
                        .user(user).warehouse(wh).build());

        req.getItems().clear();

        if (body.getItems() != null) {
            for (RequestItemLine line : body.getItems()) {
                if (line.getQuantity() == null || line.getQuantity().compareTo(BigDecimal.ZERO) <= 0)
                    continue;
                SupplyItem item = itemRepo.findById(line.getSupplyItemId())
                        .orElseThrow(() -> new ResourceNotFoundException("Vật dụng không tồn tại"));
                req.getItems().add(OfficeSupplyRequestItem.builder()
                        .request(req)
                        .supplyItem(item)
                        .quantity(line.getQuantity())
                        .note(line.getNote())
                        .build());
            }
        }

        requestRepo.save(req);
        return toMyRequestDto(req);
    }

    /** Xóa phiếu đăng ký của user cho 1 văn phòng. */
    @Transactional
    public void deleteRequest(Long warehouseId) {
        User user = currentUser();
        requestRepo.findByUserIdAndWarehouseId(user.getId(), warehouseId)
                .ifPresent(requestRepo::delete);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // OWNER: tổng hợp + đặt hàng
    // ─────────────────────────────────────────────────────────────────────────

    /** Tổng hợp toàn bộ phiếu đăng ký của 1 văn phòng. */
    @Transactional(readOnly = true)
    public OrderSummaryDto summary(Long warehouseId) {
        SupplyWarehouse wh = warehouse(warehouseId);
        List<OfficeSupplyRequest> requests = requestRepo.findAllByWarehouseIdWithItems(warehouseId);

        // Sheet 1: tổng hợp theo vật dụng
        Map<Long, SummaryRowDto> summaryMap = new LinkedHashMap<>();
        // Sheet 2: chi tiết theo nhân viên × vật dụng
        List<DetailRowDto> details = new ArrayList<>();
        int stt2 = 1;

        for (OfficeSupplyRequest req : requests) {
            String name     = req.getUser().getFullName();
            String position = req.getUser().getPosition() != null ? req.getUser().getPosition() : "";

            for (OfficeSupplyRequestItem line : req.getItems()) {
                SupplyItem si = line.getSupplyItem();

                summaryMap.merge(si.getId(),
                        SummaryRowDto.builder()
                                .stt(0)
                                .name(si.getName())
                                .specification(si.getSpecification())
                                .unit(si.getUnit())
                                .totalQuantity(line.getQuantity())
                                .build(),
                        (existing, newRow) -> {
                            existing.setTotalQuantity(existing.getTotalQuantity().add(newRow.getTotalQuantity()));
                            return existing;
                        });

                details.add(DetailRowDto.builder()
                        .stt(stt2)
                        .userId(req.getUser().getId())
                        .userFullName(name)
                        .userPosition(position)
                        .userDepartment(req.getUser().getDepartment())
                        .itemName(si.getName())
                        .unit(si.getUnit())
                        .quantity(line.getQuantity())
                        .note(line.getNote())
                        .build());
            }
        }

        // Đánh số STT cho sheet 1
        List<SummaryRowDto> summaryList = new ArrayList<>(summaryMap.values());
        for (int i = 0; i < summaryList.size(); i++) summaryList.get(i).setStt(i + 1);

        return OrderSummaryDto.builder()
                .warehouseId(wh.getId())
                .warehouseName(wh.getName())
                .summary(summaryList)
                .detail(details)
                .employeeCount(requests.size())
                .build();
    }

    /**
     * OWNER bấm "Đặt hàng":
     * 1. Tổng hợp tất cả request của văn phòng.
     * 2. Tạo OfficeSupplyOrder với items.
     * 3. Xóa toàn bộ request để tổng hợp lần sau.
     */
    @Transactional
    public OrderHistoryDto placeOrder(Long warehouseId) {
        User actor = currentUser();
        SupplyWarehouse wh = warehouse(warehouseId);
        List<OfficeSupplyRequest> requests = requestRepo.findAllByWarehouseIdWithItems(warehouseId);

        if (requests.isEmpty())
            throw new BusinessException("Chưa có phiếu đăng ký nào cho văn phòng " + wh.getName());

        OfficeSupplyOrder order = OfficeSupplyOrder.builder()
                .warehouse(wh)
                .placedAt(System.currentTimeMillis())
                .placedByName(actor.getFullName())
                .build();

        List<OfficeSupplyOrderItem> orderItems = new ArrayList<>();
        for (OfficeSupplyRequest req : requests) {
            for (OfficeSupplyRequestItem line : req.getItems()) {
                orderItems.add(OfficeSupplyOrderItem.builder()
                        .order(order)
                        .supplyItem(line.getSupplyItem())
                        .userId(req.getUser().getId())
                        .userFullName(req.getUser().getFullName())
                        .userPosition(req.getUser().getPosition())
                        .quantity(line.getQuantity())
                        .note(line.getNote())
                        .build());
            }
        }
        order.setItems(orderItems);
        orderRepo.save(order);

        // Clear toàn bộ request
        requestRepo.deleteAll(requests);

        log.info("[OfficeSupply] Đặt hàng VPP văn phòng {} — {} request, {} dòng bởi {}",
                wh.getName(), requests.size(), orderItems.size(), actor.getFullName());

        return toHistoryDto(order);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Lịch sử đặt hàng
    // ─────────────────────────────────────────────────────────────────────────

    /** Lịch sử đặt hàng của 1 văn phòng — mới nhất trước. */
    @Transactional(readOnly = true)
    public List<OrderHistoryDto> orderHistory(Long warehouseId) {
        return orderRepo.findAllByWarehouseIdOrderByPlacedAtDesc(warehouseId)
                .stream().map(this::toHistoryDto).collect(Collectors.toList());
    }

    /** Chi tiết 1 lần đặt hàng. */
    @Transactional(readOnly = true)
    public OrderDetailDto orderDetail(Long orderId) {
        OfficeSupplyOrder order = orderRepo.findByIdWithItems(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Đơn hàng không tồn tại"));
        return toDetailDto(order);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Báo cáo vật dụng
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Báo cáo theo từng vật dụng: số lần mua, ngày gần nhất, khoảng thời gian TB
     * giữa 2 lần đặt, số lượng TB mỗi lần đặt.
     *
     * <p>Không dùng {@code statsByItemAndWarehouse} nữa (chỉ đưa được MAX/SUM/COUNT).
     * Ta cần TẤT CẢ mốc {@code placedAt} để tính khoảng cách trung bình → nạp
     * hết order kèm items rồi group ở app-side. Đơn hàng VPP không nhiều nên
     * việc này rẻ và code rõ hơn viết SQL cửa sổ.
     */
    @Transactional(readOnly = true)
    public List<ItemReportRowDto> itemReport(Long warehouseId) {
        List<SupplyItem> items = itemRepo.findByDeletedAtIsNullOrderByNameAsc();
        List<com.nhatnam.server.entity.OfficeSupplyOrder> orders =
                orderRepo.findAllWithItemsByWarehouseId(warehouseId);

        // Gom theo item: mỗi item 1 danh sách (placedAt, quantity) — nạp thẳng
        // vào rowsByItem, không cần map trung gian.
        class Row { final long at; final BigDecimal qty;
            Row(long at, BigDecimal qty) { this.at = at; this.qty = qty; } }
        Map<Long, List<Row>> rowsByItem = new HashMap<>();

        for (var o : orders) {
            long at = o.getPlacedAt();
            for (var oi : o.getItems()) {
                Long itemId = oi.getSupplyItem().getId();
                rowsByItem.computeIfAbsent(itemId, k -> new ArrayList<>())
                        .add(new Row(at, oi.getQuantity() != null ? oi.getQuantity() : BigDecimal.ZERO));
            }
        }

        List<ItemReportRowDto> out = new ArrayList<>();
        for (SupplyItem it : items) {
            List<Row> rows = rowsByItem.get(it.getId());
            if (rows == null || rows.isEmpty()) continue;

            // Số lần đặt = số ORDER khác nhau có chứa item này (không phải số dòng)
            long orderCount = rows.stream().mapToLong(r -> r.at).distinct().count();
            long minAt      = rows.stream().mapToLong(r -> r.at).min().getAsLong();
            long maxAt      = rows.stream().mapToLong(r -> r.at).max().getAsLong();
            BigDecimal total = rows.stream().map(r -> r.qty)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            // Khoảng thời gian trung bình giữa 2 lần đặt (ngày). Cần ≥ 2 mốc.
            Double avgIntervalDays = null;
            if (orderCount >= 2) {
                double days = (maxAt - minAt) / 86_400_000.0;
                avgIntervalDays = days / (orderCount - 1);
            }

            // Số lượng trung bình mỗi lần đặt
            BigDecimal avgQty = null;
            if (orderCount > 0) {
                avgQty = total.divide(BigDecimal.valueOf(orderCount), 3,
                        java.math.RoundingMode.HALF_UP);
            }

            out.add(ItemReportRowDto.builder()
                    .supplyItemId(it.getId())
                    .name(it.getName())
                    .specification(it.getSpecification())
                    .unit(it.getUnit())
                    .orderCount(orderCount)
                    .lastOrderedAt(maxAt)
                    .totalQuantity(total)
                    .avgIntervalDays(avgIntervalDays)
                    .avgQuantityPerOrder(avgQty)
                    .build());
        }

        out.sort(Comparator.comparing(ItemReportRowDto::getOrderCount).reversed());
        return out;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Admin: CRUD danh mục vật dụng
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Danh sách vật dụng đầy đủ cho trang "Danh sách văn phòng phẩm" (Owner add/edit).
     * Không kèm tồn kho — module VPP không dùng kho vật lý.
     */
    @Transactional(readOnly = true)
    public List<AdminItemDto> adminListItems() {
        return itemRepo.findByDeletedAtIsNullOrderByNameAsc().stream()
                .map(it -> AdminItemDto.builder()
                        .id(it.getId())
                        .name(it.getName())
                        .specification(it.getSpecification())
                        .unit(it.getUnit())
                        .createdAt(it.getCreatedAt())
                        .updatedAt(it.getUpdatedAt())
                        .build())
                .collect(Collectors.toList());
    }

    /**
     * Tạo mới hoặc sửa vật dụng. Tận dụng {@code SupplyItemService.getOrCreate}
     * để đảm bảo unique theo bộ ba đã chuẩn hoá (tên, quy cách, ĐVT).
     */
    @Transactional
    public AdminItemDto adminCreateItem(SaveItemBody body, SupplyItemService supplyItemService) {
        if (body == null || body.getName() == null || body.getName().isBlank())
            throw new com.nhatnam.server.common.BusinessException("Tên vật dụng là bắt buộc");
        if (body.getUnit() == null || body.getUnit().isBlank())
            throw new com.nhatnam.server.common.BusinessException("Đơn vị tính là bắt buộc");

        SupplyItem it = supplyItemService.getOrCreate(
                body.getName(), body.getSpecification(), body.getUnit());
        return AdminItemDto.builder()
                .id(it.getId())
                .name(it.getName())
                .specification(it.getSpecification())
                .unit(it.getUnit())
                .createdAt(it.getCreatedAt())
                .updatedAt(it.getUpdatedAt())
                .build();
    }

    /**
     * Sửa NHÃN HIỂN THỊ (name/spec/unit) của item.
     *
     * <p>KHÁC {@code getOrCreate}: getOrCreate là "tìm-hoặc-tạo" dùng khi lưu phiếu,
     * còn ở đây Owner đang chủ đích SỬA bản ghi hiện có. Nếu bộ ba mới đụng bản
     * ghi khác thì báo lỗi để Owner đi con đường merge thay vì tạo double.
     */
    @Transactional
    public AdminItemDto adminUpdateItem(Long id, SaveItemBody body) {
        if (body == null || body.getName() == null || body.getName().isBlank())
            throw new com.nhatnam.server.common.BusinessException("Tên vật dụng là bắt buộc");
        if (body.getUnit() == null || body.getUnit().isBlank())
            throw new com.nhatnam.server.common.BusinessException("Đơn vị tính là bắt buộc");

        SupplyItem it = itemRepo.findById(id)
                .orElseThrow(() -> new com.nhatnam.server.common.ResourceNotFoundException(
                        "Vật dụng không tồn tại"));
        if (it.getDeletedAt() != null)
            throw new com.nhatnam.server.common.BusinessException("Vật dụng đã bị xoá / gộp");

        String nameNorm = SupplyItem.normalize(body.getName());
        String specNorm = SupplyItem.normalize(body.getSpecification());
        String unitNorm = SupplyItem.normalizeUnit(body.getUnit());

        // Nếu bộ ba mới khác bộ ba hiện tại, kiểm tra không đụng bản ghi khác
        if (!nameNorm.equals(it.getNameNormalized())
                || !specNorm.equals(it.getSpecNormalized())
                || !unitNorm.equals(it.getUnitNormalized())) {
            itemRepo.findByNameNormalizedAndSpecNormalizedAndUnitNormalizedAndDeletedAtIsNull(
                    nameNorm, specNorm, unitNorm)
                .filter(other -> !other.getId().equals(id))
                .ifPresent(other -> {
                    throw new com.nhatnam.server.common.BusinessException(
                            "Đã có vật dụng khác cùng (tên, quy cách, ĐVT). "
                            + "Nếu cần hợp nhất hãy dùng chức năng Gộp.");
                });
        }

        it.setName(body.getName().trim().replaceAll("\\s+", " "));
        it.setSpecification(body.getSpecification() == null || body.getSpecification().isBlank()
                ? null : body.getSpecification().trim().replaceAll("\\s+", " "));
        it.setUnit(body.getUnit().trim().replaceAll("\\s+", " "));
        it.setNameNormalized(nameNorm);
        it.setSpecNormalized(specNorm);
        it.setUnitNormalized(unitNorm);
        itemRepo.save(it);

        return AdminItemDto.builder()
                .id(it.getId())
                .name(it.getName())
                .specification(it.getSpecification())
                .unit(it.getUnit())
                .createdAt(it.getCreatedAt())
                .updatedAt(it.getUpdatedAt())
                .build();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Mappers
    // ─────────────────────────────────────────────────────────────────────────

    private MyRequestDto toMyRequestDto(OfficeSupplyRequest req) {
        return MyRequestDto.builder()
                .warehouseId(req.getWarehouse().getId())
                .warehouseName(req.getWarehouse().getName())
                .items(req.getItems().stream().map(i -> RequestItemDto.builder()
                        .supplyItemId(i.getSupplyItem().getId())
                        .name(i.getSupplyItem().getName())
                        .specification(i.getSupplyItem().getSpecification())
                        .unit(i.getSupplyItem().getUnit())
                        .quantity(i.getQuantity())
                        .note(i.getNote())
                        .build()).collect(Collectors.toList()))
                .updatedAt(req.getUpdatedAt())
                .build();
    }

    private OrderHistoryDto toHistoryDto(OfficeSupplyOrder o) {
        BigDecimal totalQty = o.getItems().stream()
                .map(OfficeSupplyOrderItem::getQuantity)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        long itemTypes = o.getItems().stream()
                .map(i -> i.getSupplyItem().getId()).distinct().count();
        return OrderHistoryDto.builder()
                .id(o.getId())
                .warehouseId(o.getWarehouse().getId())
                .warehouseName(o.getWarehouse().getName())
                .placedAt(o.getPlacedAt())
                .placedByName(o.getPlacedByName())
                .itemTypeCount((int) itemTypes)
                .totalQuantity(totalQty)
                .build();
    }

    private OrderDetailDto toDetailDto(OfficeSupplyOrder o) {
        return OrderDetailDto.builder()
                .id(o.getId())
                .warehouseId(o.getWarehouse().getId())
                .warehouseName(o.getWarehouse().getName())
                .placedAt(o.getPlacedAt())
                .placedByName(o.getPlacedByName())
                .items(o.getItems().stream().map(i -> OrderDetailItemDto.builder()
                        .userId(i.getUserId())
                        .userFullName(i.getUserFullName())
                        .userPosition(i.getUserPosition())
                        .supplyItemId(i.getSupplyItem().getId())
                        .itemName(i.getSupplyItem().getName())
                        .unit(i.getSupplyItem().getUnit())
                        .specification(i.getSupplyItem().getSpecification())
                        .quantity(i.getQuantity())
                        .note(i.getNote())
                        .build()).collect(Collectors.toList()))
                .build();
    }
}
